import 'package:flutter/material.dart';
import 'flutter_flow/flutter_flow_util.dart';

abstract class FFAppConstants {
  static const bool isFavourite = true;
  static const int contact = 441483861599;
  static const int newCartCount = 1;
}
